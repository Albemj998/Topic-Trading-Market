#include <iostream>
#include <ctime>

using namespace std;

float shop(void);

int main() {

    char start, choice;

startL:
    cout << "Please press H to shop for home appliances: " << endl;

start:
    cin >> start;

    if (start == 'h' || start == 'H') {
        float total = shop();
        time_t t = time(NULL);
        tm* tPtr = localtime(&t);

        cout << "Bill Date : " << endl;
        cout << tPtr->tm_mday << "/" << 1 + tPtr->tm_mon << "/" << 1900 + tPtr->tm_year << endl;
        cout << "Bill time: " << (tPtr->tm_hour) << ":" << (tPtr->tm_min) << ":" << (tPtr->tm_sec) << endl;
        cout << "Total Bill Amount : " << total << endl;

        if (total > 50000 && total <= 100000) {
            total = total - (0.05 * total);
            cout << "Total discount : 5% " << endl;
        }
        else if (total > 100000 && total <= 125000) {
            total = total - (0.1 * total);
            cout << "Total discount : 10% " << endl;
        }
        else if (total > 125000 && total <= 500000) {
            total = total - (0.25 * total);
            cout << "Total discount : 25% " << endl;
        }
        else if (total > 500000 && total <= 900000) {
            total = total - (0.3 * total);
            cout << "Total discount : 30% " << endl;
        }

        cout << "Total bill amount is : " << total << endl;

    Again:
        cout << "Would You like to Shop for more items " << endl;
        cout << " Y or N : " << endl;
        cin >> choice;

        if (choice == 'y' || choice == 'Y') {
            goto startL;
        }
        else if (choice == 'n' || choice == 'N') {
            cout << "Thank You for Shopping with Us. " << endl;
        }
        else {
            cout << "You have entered a wrong option, Please press H to start again." << endl;
        }
    }
    else {
        cout << "You have entered the wrong option, Please press H to shop again." << endl;
        goto start;
    }

    return 0;
}

float shop() {
    char choice, product;
    int quantity;
    float bill = 0;

itemLevel:
    cout << "**********Welcome**********" << endl;
    cout << "__Please follow the instructions__" << endl;
    cout << "| 1) Please Enter r to order a Refrigerator " << endl;
    cout << "| 2) Please Enter w to order a Washing Machine " << endl;
    cout << "| 3) Please Enter t to order a Television " << endl;
    cout << "| 4) Please Enter m to order a Microwave " << endl;
    cout << "| 5) Please Enter a to order an Air Condition " << endl;

    cin >> choice;

    switch (choice) {
    case 'r':
    case 'R':
        cout << "___________Refrigerator____________" << endl;
        cout << "| 1) Whirlpool  =  Price : 6500 |" << endl;
        cout << "| 2) Samsung    =  Price : 8990 |" << endl;
        cout << "| 3) LG         =  Price : 7500 |" << endl;
        cout << "| 4) Binatone   =  Price : 9100 |" << endl;
        cout << "| 5) Hisense    =  Price : 9700 |" << endl;
        break;
    case 'w':
    case 'W':
        cout << "___________Washing Machine____________" << endl;
        cout << "| 1) Bosch      =  Price : 6700 |" << endl;
        cout << "| 2) Samsung    =  Price : 8090 |" << endl;
        cout << "| 3) LG         =  Price : 7000 |" << endl;
        cout << "| 4) Haier      =  Price : 6990 |" << endl;
        cout << "| 5) Hisense    =  Price : 8400 |" << endl;
        break;
    case 't':
    case 'T':
        cout << "___________Television____________" << endl;
        cout << "| 1) Sharp      =  Price : 7900 |" << endl;
        cout << "| 2) Samsung    =  Price : 9700 |" << endl;
        cout << "| 3) LG         =  Price : 8590 |" << endl;
        cout << "| 4) TCL        =  Price : 8990 |" << endl;
        cout << "| 5) Hisense    =  Price : 9400 |" << endl;
        break;
    case 'm':
    case 'M':
        cout << "___________Microwave____________" << endl;
        cout << "| 1) Bosch      =  Price : 2700 |" << endl;
        cout << "| 2) Samsung    =  Price : 3500 |" << endl;
        cout << "| 3) LG         =  Price : 2990 |" << endl;
        cout << "| 4) Haier      =  Price : 3500 |" << endl;
        cout << "| 5) Hisense    =  Price : 4000 |" << endl;
        break;
    case 'a':
    case 'A':
        cout << "___________Air Condition____________" << endl;
        cout << "| 1) Bosch      =  Price : 3400 |" << endl;
        cout << "| 2) Samsung    =  Price : 5000 |" << endl;
        cout << "| 3) LG         =  Price : 6000 |" << endl;
        cout << "| 4) Haier      =  Price : 4990 |" << endl;
        cout << "| 5) Hisense    =  Price : 4999 |" << endl;
        break;
    default:
        cout << "You have entered the wrong option, Please try again." << endl;
        goto itemLevel;
    }

    cout << "Please Enter your choice " << endl;
    cin >> product;

    switch (product) {
    case '1':
        cout << "Please enter the quantity of the product:" << endl;
        cin >> quantity;
        bill += quantity * 6500;
        break;
    case '2':
        cout << "Please enter the quantity of the product:" << endl;
        cin >> quantity;
        bill += quantity * 8990;
        break;
    case '3':
        cout << "Please enter the quantity of the product:" << endl;
        cin >> quantity;
        bill += quantity * 7500;
        break;
    case '4':
        cout << "Please enter the quantity of the product:" << endl;
        cin >> quantity;
        bill += quantity * 9100;
        break;
    case '5':
        cout << "Please enter the quantity of the product:" << endl;
        cin >> quantity;
        bill += quantity * 9700;
        break;
    default:
        cout << "You have entered the wrong option, Please try again." << endl;
        goto itemLevel;
    }

    return bill;
}

